# MyConsense Component for Joomla!
Find the consense in your Comunity
